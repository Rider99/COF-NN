import os
import yaml
import csv
import pandas as pd
import numpy as np
from scipy.optimize import curve_fit
import shutil
import subprocess
from ase import Atoms
from ase.io import read, write

# Part 1: Extract energy and lattice constant from posout.yaml and save to CSV

# Define the base directory
base_dir = "./opt_lattice"
current_dir = os.getcwd()
current_dir_name = os.path.basename(current_dir)
output_csv = os.path.join(base_dir, f"energy_lattice_values_{current_dir_name}.csv")

# Hartree to eV conversion factor
hartree_to_ev = 27.2114

# Get all subdirectories
subdirs = [d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))]

# Open the CSV file for writing
with open(output_csv, mode='w', newline='') as file:
    writer = csv.writer(file)
    # Write the header row
    writer.writerow(["Directory", "Energy (eV)", "Lattice Constant a (Å)"])

    # Process each subdirectory
    for subdir in subdirs:
        posout_path = os.path.join(base_dir, subdir, "posout.yaml")

        if os.path.exists(posout_path):
            with open(posout_path, 'r') as stream:
                try:
                    # Load multiple documents from the YAML file
                    documents = yaml.safe_load_all(stream)
                    for doc in documents:
                        # Extract the energy value under 'conf' and convert to eV
                        energy_hartree = doc.get("conf", {}).get("epot", None)
                        energy_ev = energy_hartree * hartree_to_ev if energy_hartree is not None else None

                        # Extract the lattice constant 'a'
                        cell = doc.get("conf", {}).get("cell", None)
                        if cell is not None and len(cell) > 0 and len(cell[0]) > 0:
                            lattice_constant_a = cell[0][0]
                        else:
                            lattice_constant_a = None

                        if energy_ev is not None and lattice_constant_a is not None:
                            # Print and save the results
                            print(f"Directory: {subdir}, Energy (eV): {energy_ev}, Lattice Constant a (Å): {lattice_constant_a}")
                            writer.writerow([subdir, energy_ev, lattice_constant_a])
                        else:
                            print(f"Energy or Lattice constant not found in {posout_path}")
                except yaml.YAMLError as exc:
                    print(f"Error reading YAML file {posout_path}: {exc}")
        else:
            print(f"posout.yaml not found in {subdir}")

print(f"Energy and lattice constant values have been saved to {output_csv}")

# Part 2: Fit the data to a cubic function and find the minimum energy

# Load the CSV file generated previously
data_df = pd.read_csv(output_csv)

# Extract lattice constant and energy values
lattice_constants = data_df['Lattice Constant a (Å)'].values
energies = data_df['Energy (eV)'].values

# Sort the data by lattice constants (optional, but helps with plotting and fitting)
sorted_indices = np.argsort(lattice_constants)
lattice_constants = lattice_constants[sorted_indices]
energies = energies[sorted_indices]

# Define a cubic function
def cubic(x, a, b, c, d):
    return a*x**3 + b*x**2 + c*x + d

# Fit the data to a cubic function
try:
    cubic_params, _ = curve_fit(cubic, lattice_constants, energies)
except RuntimeError as e:
    print(f"Error in curve fitting: {e}")
    exit(1)

# Compute the derivative to find critical points (extrema)
a_coef, b_coef, c_coef, d_coef = cubic_params
# The derivative is f'(x) = 3ax^2 + 2bx + c
coefficients = [3*a_coef, 2*b_coef, c_coef]
critical_points = np.roots(coefficients)

# Filter real critical points
critical_points = critical_points[np.isreal(critical_points)].real

# Calculate the second derivative to determine minima
# f''(x) = 6ax + 2b
second_derivative = 6*a_coef*critical_points + 2*b_coef

# Find minima
min_points = critical_points[second_derivative > 0]

if len(min_points) == 0:
    print("No minimum found in the fitted function.")
    exit(1)
else:
    # Calculate the energy values at these minima
    y_min_cubic = cubic(min_points, a_coef, b_coef, c_coef, d_coef)
    # Sort minima by energy to find the global minimum
    min_index = np.argmin(y_min_cubic)
    lattice_min = min_points[min_index]
    energy_min = y_min_cubic[min_index]
    # Calculate half of the minimum lattice constant
    lattice_half = lattice_min / 2
    # Calculate lattice_min * (-√3 / 2)
    lattice_sqrt3_half = lattice_min * (np.sqrt(3) / 2)  # Negative value as per your requirement

    # Print the results
    print(f"Lattice Constant at Minimum: {lattice_min:.15f}")
    print(f"Energy at Minimum: {energy_min:.15f} eV")
    print(f"Half of the Lattice Constant at Minimum: {lattice_half:.15f}")
    print(f"Lattice Constant at Minimum multiplied by √3/2: {lattice_sqrt3_half:.15f}")

# Part 3: Copy POSCAR to 'afopt' directory and modify its content using ASE

# Create 'afopt' directory if it doesn't exist
afopt_dir = os.path.join(current_dir, 'afopt')
os.makedirs(afopt_dir, exist_ok=True)

# Copy a POSCAR file into 'afopt' directory
# Assuming the original POSCAR file is in the current directory or specify the path
original_poscar_path = os.path.join(current_dir, 'POSCAR')  # Modify this path if needed
afopt_poscar_path = os.path.join(afopt_dir, 'Ori_POSCAR')

if os.path.exists(original_poscar_path):
    shutil.copy(original_poscar_path, afopt_poscar_path)
    print(f"Copied POSCAR to {afopt_poscar_path}")
else:
    print(f"Original POSCAR file not found at {original_poscar_path}")
    exit(1)

# Use ASE to read, modify, and write the POSCAR file
try:
    # Read the POSCAR file using ASE
    atoms = read(afopt_poscar_path, format='vasp')

    # Modify the cell
    cell = atoms.get_cell()

    # Update the lattice vectors
    # First lattice vector: [lattice_min, 0, 0]
    cell[0, :] = [lattice_min, 0.0, 0.0]
    # Second lattice vector: [lattice_half, lattice_sqrt3_half, 0]
    cell[1, :] = [-lattice_half, lattice_sqrt3_half, 0.0]
    # Third lattice vector: [0, 0, 30]
    cell[2, :] = [0.0, 0.0, 30.0]

    # Set the updated cell back to atoms
    atoms.set_cell(cell, scale_atoms=True)

    # Write the modified POSCAR file
    write(afopt_poscar_path, atoms, format='vasp')
    print(f"Modified POSCAR file saved to {afopt_poscar_path}")
except Exception as e:
    print(f"Error modifying POSCAR file with ASE: {e}")
    exit(1)

# Part 4: Convert the modified POSCAR to posinp.yaml using poscar2yaml.py

# Path to the poscar2yaml.py script
poscar2yaml_script = "/blue/mingjieliu/so.farajinafchi/softwares/FLAME/utils/python/poscar2yaml.py"

# Paths for the POSCAR and output posinp.yaml
poscar_path = afopt_poscar_path
posinp_yaml_path = os.path.join(afopt_dir, 'posinp.yaml')

# Run the poscar2yaml.py script
try:
    subprocess.run(['python3', poscar2yaml_script, poscar_path, posinp_yaml_path], check=True)
    print(f"Converted {poscar_path} to {posinp_yaml_path}")
except subprocess.CalledProcessError as e:
    print(f"Error converting POSCAR to posinp.yaml. Error message: {e}")

