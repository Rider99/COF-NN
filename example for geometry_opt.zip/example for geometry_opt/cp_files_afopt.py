import os
import shutil

# 获取当前目录的绝对路径
current_dir = os.path.abspath('.')

# 定义要复制的文件列表
files_to_copy = [
    'C.ann.param.yaml',
    'H.ann.param.yaml',
    'O.ann.param.yaml',
    'N.ann.param.yaml',
    'flame_in.yaml',
    'run.sh'
]

# 定义目标子目录 'afopt'
target_dir = os.path.join(current_dir, 'afopt')

# 如果目标子目录不存在，则创建它
if not os.path.exists(target_dir):
    os.makedirs(target_dir)
    print(f"已创建目录：{target_dir}")

# 复制文件到目标子目录
for file_name in files_to_copy:
    source_file = os.path.join(current_dir, file_name)
    target_file = os.path.join(target_dir, file_name)
    if os.path.exists(source_file):
        shutil.copy(source_file, target_file)
        print(f"已将 {file_name} 复制到 {target_dir}")
    else:
        print(f"源文件 {source_file} 不存在，无法复制。")

