import os
import shutil
import subprocess
import re
from ase.io import read, write

def copy_poscar():
    # 从指定目录复制 POSCAR 文件到当前目录
    source_poscar_path = "/blue/mingjieliu/yunrui.yan/Train/COF_test_Young/1159_kgm/ori_POSCAR"
    destination_poscar_path = "POSCAR"
    
    try:
        shutil.copyfile(source_poscar_path, destination_poscar_path)
        print(f"已将 ori_POSCAR 从 {source_poscar_path} 复制到 {destination_poscar_path}")
    except Exception as e:
        print(f"复制 POSCAR 文件时出错: {e}")
        exit()

def apply_strain_and_save(poscar_path, strains, base_dir):
    # 创建包含所有子目录的主目录
    uni_dir = os.path.join(base_dir, 'opt_lattice')
    try:
        os.makedirs(uni_dir, exist_ok=True)
        print(f"Created or verified main directory: {uni_dir}")
    except Exception as e:
        print(f"Error creating main directory: {e}")
        return

    # 读取原始 POSCAR 文件
    try:
        original_structure = read(poscar_path, format='vasp')
        print(f"Read original structure from {poscar_path}")
    except Exception as e:
        print(f"Error reading POSCAR file: {e}")
        return

    for strain in strains:
        # 复制原始结构以应用应变
        structure = original_structure.copy()

        # 应用应变（如果应变不为零）
        if strain != 0:
            lattice_vectors = structure.cell.copy()
            lattice_vectors[0][0] *= (1 + strain)
            lattice_vectors[1][0] *= (1 + strain)
            lattice_vectors[1][1] *= (1 + strain)
            structure.set_cell(lattice_vectors, scale_atoms=True)
        print(f"Applied strain: {strain}")

        # 使用正号格式化字符串
        strain_str = f'{strain:+.3f}'  # +.3f 格式化字符串会在正数前加上+
        strain_dir = os.path.join(uni_dir, f'strain_{strain_str}')

        try:
            os.makedirs(strain_dir, exist_ok=True)
            print(f"Created or verified strain directory: {strain_dir}")
        except Exception as e:
            print(f"Error creating strain directory: {e}")
            continue

        output_file = os.path.join(strain_dir, 'POSCAR')
        try:
            write(output_file, structure, format='vasp', vasp5=True, direct=True)
            print(f"Saved modified structure to {output_file}")
        except Exception as e:
            print(f"Error writing file: {e}")
            continue

def copy_files_to_current_and_subdirs():
    # 获取当前目录的绝对路径
    current_dir = os.path.abspath('.')

    # 第一步：从上三级目录复制文件并重命名
    # 获取上两级目录的目录名
    parent_dir_two_up = os.path.basename(os.path.abspath(os.path.join(current_dir, '../../')))

    # 提取目录名中的数字部分
    match = re.search(r'(\d+)', parent_dir_two_up)
    if match:
        number_part = match.group(1)
    else:
        print(f"Error: Could not extract numeric part from directory name {parent_dir_two_up}")
        number_part = 'unknown'

    # 定义源目录（上三级目录）
    source_base_dir = os.path.abspath(os.path.join(current_dir, '../../../'))

    # 要处理的元素列表
    elements = ['C', 'N', 'O', 'H']

    for element in elements:
        source_filename = f"{element}.ann.param.yaml.{number_part}"
        source_file_path = os.path.join(source_base_dir, source_filename)
        target_file_path = os.path.join(current_dir, f"{element}.ann.param.yaml")

        if os.path.exists(source_file_path):
            shutil.copy(source_file_path, target_file_path)
            print(f"已将 {source_filename} 复制到 {current_dir} 并重命名为 {element}.ann.param.yaml")
        else:
            print(f"错误：源文件 {source_file_path} 不存在。")

    # 从指定目录复制 flame_in.yaml 到当前目录
    source_dir_ann_opt = '/blue/mingjieliu/yunrui.yan/Train/train_Behler_c3/train0055/test00017/test_COF/ANN_55_17_c3_opt_COF_151'
    source_flame_in = os.path.join(source_dir_ann_opt, 'flame_in.yaml')
    target_flame_in = os.path.join(current_dir, 'flame_in.yaml')

    if os.path.exists(source_flame_in):
        shutil.copy(source_flame_in, target_flame_in)
        print(f"已将 flame_in.yaml 复制到 {current_dir}")
    else:
        print(f"错误：源文件 {source_flame_in} 不存在。")

    # 复制其他文件到当前目录
    additional_files = [
        'extract_fitting.py',
        'cp_files_afopt.py'
    ]

    for file_name in additional_files:
        source_file = os.path.join(source_dir_ann_opt, file_name)
        target_file = os.path.join(current_dir, file_name)
        if os.path.exists(source_file):
            shutil.copy(source_file, target_file)
            print(f"已将 {file_name} 复制到 {current_dir}")
        else:
            print(f"错误：源文件 {source_file} 不存在。")

    # 第二步：将文件复制到每个子目录
    # 定义源文件列表
    source_files = [
        "C.ann.param.yaml",
        "flame_in.yaml",
        "H.ann.param.yaml",
        "N.ann.param.yaml",
        "O.ann.param.yaml"
    ]

    # 定义目标目录的基础路径
    target_base_dir = os.path.join(current_dir, "opt_lattice")

    # 获取目标目录下的所有子目录
    try:
        subdirs = [d for d in os.listdir(target_base_dir) if os.path.isdir(os.path.join(target_base_dir, d))]
    except FileNotFoundError:
        print(f"错误：目标目录 {target_base_dir} 不存在。")
        subdirs = []

    # 将文件复制到每个子目录
    for subdir in subdirs:
        subdir_path = os.path.join(target_base_dir, subdir)

        # 确保目标子目录存在
        if not os.path.exists(subdir_path):
            os.makedirs(subdir_path)

        # 复制文件并处理异常
        for file in source_files:
            source_file_path = os.path.join(current_dir, file)
            target_file_path = os.path.join(subdir_path, file)

            if os.path.exists(source_file_path):
                shutil.copy(source_file_path, target_file_path)
                print(f"已将 {file} 复制到 {subdir_path}")
            else:
                print(f"错误：源文件 {source_file_path} 不存在。")

def run_poscar2yaml_and_flame():
    # 获取当前目录的绝对路径
    current_dir = os.path.abspath('.')

    # 定义基目录为当前目录下的 opt_lattice
    base_dir = os.path.join(current_dir, 'opt_lattice')

    # 定义 poscar2yaml.py 脚本的路径
    poscar2yaml_script = "/blue/mingjieliu/so.farajinafchi/softwares/FLAME/utils/python/poscar2yaml.py"

    # 获取基目录下的所有子目录
    try:
        subdirs = [d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))]
    except FileNotFoundError:
        print(f"错误：目标目录 {base_dir} 不存在。")
        return

    # 处理每个子目录
    for subdir in subdirs:
        subdir_path = os.path.join(base_dir, subdir)
        poscar_path = os.path.join(subdir_path, 'POSCAR')
        output_path = os.path.join(subdir_path, 'posinp.yaml')

        # 运行 poscar2yaml.py 脚本
        if os.path.exists(poscar_path):
            try:
                subprocess.run(['python3', poscar2yaml_script, poscar_path, output_path], check=True)
                print(f"已将 {poscar_path} 转换为 {output_path}")
            except subprocess.CalledProcessError as e:
                print(f"错误：转换 {poscar_path} 失败。错误信息: {e}")
        else:
            print(f"错误：{poscar_path} 不存在，无法转换。")

        # 运行 FLAME 程序
        flame_executable = "/blue/mingjieliu/so.farajinafchi/softwares/FLAME/build-FLAME/src/flame"
        if os.path.exists(flame_executable):
            try:
                subprocess.run([flame_executable], cwd=subdir_path, stdout=open(os.path.join(subdir_path, 'o1.out'), 'w'), stderr=subprocess.STDOUT)
                print(f"已在目录 {subdir_path} 中运行 FLAME")
            except Exception as e:
                print(f"错误：在目录 {subdir_path} 中运行 FLAME 失败。错误信息: {e}")
        else:
            print(f"错误：FLAME 可执行文件 {flame_executable} 不存在。")

def main():
    # 第一步：复制 POSCAR 文件
    copy_poscar()

    # 第二步：应用应变并保存结构
    strains = [-0.050, -0.040, -0.030, -0.020, -0.010, 0.000, +0.010, +0.020, +0.030, +0.040, +0.050]
    opt_poscar_path = "POSCAR"  # POSCAR 文件位于当前目录
    base_dir = "."  # 基础目录为当前目录
    apply_strain_and_save(opt_poscar_path, strains, base_dir)

    # 第三步：复制文件到当前目录和子目录
    copy_files_to_current_and_subdirs()

    # 第四步：在每个子目录中运行 poscar2yaml.py 和 FLAME
    run_poscar2yaml_and_flame()

if __name__ == "__main__":
    main()

