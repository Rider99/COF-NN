#!/bin/bash
#SBATCH --job-name=Test_COF_opt
#SBATCH --mail-user=yrui9916@gmail.com
#SBATCH --mail-type=FAIL,END
#SBATCH --output=tjob_%j.out
#SBATCH --error=tjob_%j.err
#SBATCH --cpus-per-task=2
#SBATCH --mem-per-cpu=2gb
#SBATCH --time=03:00:00
#SBATCH --distribution=cyclic:cyclic
#SBATCH --account=mingjieliu
#SBATCH --ntasks=1

/blue/mingjieliu/so.farajinafchi/softwares/FLAME/build-FLAME/src/flame > o1.out

