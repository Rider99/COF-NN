import os
import shutil
import yaml
import csv
import pandas as pd
import numpy as np
from scipy.optimize import curve_fit
import subprocess
from ase import Atoms
from ase.io import read, write
import re

def copy_files_to_afopt():
    # 获取当前目录的绝对路径
    current_dir = os.path.abspath('.')

    # 定义要复制的文件列表
    files_to_copy = [
        'C.ann.param.yaml',
        'H.ann.param.yaml',
        'O.ann.param.yaml',
        'N.ann.param.yaml',
        'flame_in.yaml',
        'run.sh'
    ]

    # 定义目标子目录 'afopt'
    target_dir = os.path.join(current_dir, 'afopt')

    # 如果目标子目录不存在，则创建它
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
        print(f"已创建目录：{target_dir}")

    # 定义 run.sh 的源目录
    run_sh_source_dir = '/blue/mingjieliu/yunrui.yan/Train/train_Behler_c3/train0055/test00018/test_COF/ANN_55_18_c3_opt_COF_151'

    # 复制文件到目标子目录
    for file_name in files_to_copy:
        if file_name == 'run.sh':
            source_file = os.path.join(run_sh_source_dir, file_name)
        else:
            source_file = os.path.join(current_dir, file_name)
        target_file = os.path.join(target_dir, file_name)
        if os.path.exists(source_file):
            shutil.copy(source_file, target_file)
            print(f"已将 {file_name} 复制到 {target_dir}")
        else:
            print(f"源文件 {source_file} 不存在，无法复制。")

def extract_energy_and_modify_poscar():
    # Part 1: Extract energy and lattice constant from posout.yaml and save to CSV

    # Define the base directory
    base_dir = "./opt_lattice"
    current_dir = os.getcwd()
    current_dir_name = os.path.basename(current_dir)
    output_csv = os.path.join(base_dir, f"energy_lattice_values_{current_dir_name}.csv")

    # Hartree to eV conversion factor
    hartree_to_ev = 27.2114

    # Get all subdirectories
    subdirs = [d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))]

    # Open the CSV file for writing
    with open(output_csv, mode='w', newline='') as file:
        writer = csv.writer(file)
        # Write the header row
        writer.writerow(["Directory", "Energy (eV)", "Lattice Constant a (Å)"])

        # Process each subdirectory
        for subdir in subdirs:
            posout_path = os.path.join(base_dir, subdir, "posout.yaml")

            if os.path.exists(posout_path):
                with open(posout_path, 'r') as stream:
                    try:
                        # Load multiple documents from the YAML file
                        documents = yaml.safe_load_all(stream)
                        for doc in documents:
                            # Extract the energy value under 'conf' and convert to eV
                            energy_hartree = doc.get("conf", {}).get("epot", None)
                            energy_ev = energy_hartree * hartree_to_ev if energy_hartree is not None else None

                            # Extract the lattice constant 'a'
                            cell = doc.get("conf", {}).get("cell", None)
                            if cell is not None and len(cell) > 0 and len(cell[0]) > 0:
                                lattice_constant_a = cell[0][0]
                            else:
                                lattice_constant_a = None

                            if energy_ev is not None and lattice_constant_a is not None:
                                # Print and save the results
                                print(f"Directory: {subdir}, Energy (eV): {energy_ev}, Lattice Constant a (Å): {lattice_constant_a}")
                                writer.writerow([subdir, energy_ev, lattice_constant_a])
                            else:
                                print(f"Energy or Lattice constant not found in {posout_path}")
                    except yaml.YAMLError as exc:
                        print(f"Error reading YAML file {posout_path}: {exc}")
            else:
                print(f"posout.yaml not found in {subdir}")

    print(f"Energy and lattice constant values have been saved to {output_csv}")

    # Part 2: Fit the data to a cubic function and find the minimum energy

    # Load the CSV file generated previously
    data_df = pd.read_csv(output_csv)

    # Extract lattice constant and energy values
    lattice_constants = data_df['Lattice Constant a (Å)'].values
    energies = data_df['Energy (eV)'].values

    # Sort the data by lattice constants
    sorted_indices = np.argsort(lattice_constants)
    lattice_constants = lattice_constants[sorted_indices]
    energies = energies[sorted_indices]

    # Define a cubic function
    def cubic(x, a, b, c, d):
        return a*x**3 + b*x**2 + c*x + d

    # Fit the data to a cubic function
    try:
        cubic_params, _ = curve_fit(cubic, lattice_constants, energies)
    except RuntimeError as e:
        print(f"Error in curve fitting: {e}")
        return

    # Compute the derivative to find critical points (extrema)
    a_coef, b_coef, c_coef, d_coef = cubic_params
    # The derivative is f'(x) = 3ax^2 + 2bx + c
    coefficients = [3*a_coef, 2*b_coef, c_coef]
    critical_points = np.roots(coefficients)

    # Filter real critical points
    critical_points = critical_points[np.isreal(critical_points)].real

    # Calculate the second derivative to determine minima
    # f''(x) = 6ax + 2b
    second_derivative = 6*a_coef*critical_points + 2*b_coef

    # Find minima
    min_points = critical_points[second_derivative > 0]

    if len(min_points) == 0:
        print("No minimum found in the fitted function.")
        return
    else:
        # Calculate the energy values at these minima
        y_min_cubic = cubic(min_points, a_coef, b_coef, c_coef, d_coef)
        # Sort minima by energy to find the global minimum
        min_index = np.argmin(y_min_cubic)
        lattice_min = min_points[min_index]
        energy_min = y_min_cubic[min_index]
        # Calculate half of the minimum lattice constant
        lattice_half = lattice_min / 2
        # Calculate lattice_min * (√3 / 2)
        lattice_sqrt3_half = lattice_min * (np.sqrt(3) / 2)

        # Print the results
        print(f"Lattice Constant at Minimum: {lattice_min:.15f}")
        print(f"Energy at Minimum: {energy_min:.15f} eV")
        print(f"Half of the Lattice Constant at Minimum: {lattice_half:.15f}")
        print(f"Lattice Constant at Minimum multiplied by √3/2: {lattice_sqrt3_half:.15f}")

    # Part 3: Copy POSCAR to 'afopt' directory and modify its content using ASE

    # Create 'afopt' directory if it doesn't exist
    afopt_dir = os.path.join(current_dir, 'afopt')
    os.makedirs(afopt_dir, exist_ok=True)

    # Copy a POSCAR file into 'afopt' directory
    # Assuming the original POSCAR file is in the current directory
    original_poscar_path = os.path.join(current_dir, 'POSCAR')
    afopt_poscar_path = os.path.join(afopt_dir, 'Ori_POSCAR')

    if os.path.exists(original_poscar_path):
        shutil.copy(original_poscar_path, afopt_poscar_path)
        print(f"Copied POSCAR to {afopt_poscar_path}")
    else:
        print(f"Original POSCAR file not found at {original_poscar_path}")
        return

    # Use ASE to read, modify, and write the POSCAR file
    try:
        # Read the POSCAR file using ASE
        atoms = read(afopt_poscar_path, format='vasp')

        # Modify the cell
        cell = atoms.get_cell()

        # Update the lattice vectors
        # First lattice vector: [lattice_min, 0, 0]
        cell[0, :] = [lattice_min, 0.0, 0.0]
        # Second lattice vector: [-lattice_half, lattice_sqrt3_half, 0]
        cell[1, :] = [-lattice_half, lattice_sqrt3_half, 0.0]
        # Third lattice vector: [0, 0, 30]
        cell[2, :] = [0.0, 0.0, 30.0]

        # Set the updated cell back to atoms
        atoms.set_cell(cell, scale_atoms=True)

        # Write the modified POSCAR file
        write(afopt_poscar_path, atoms, format='vasp')
        print(f"Modified POSCAR file saved to {afopt_poscar_path}")
    except Exception as e:
        print(f"Error modifying POSCAR file with ASE: {e}")
        return

    # Part 4: Convert the modified POSCAR to posinp.yaml using poscar2yaml.py

    # Path to the poscar2yaml.py script
    poscar2yaml_script = "/blue/mingjieliu/so.farajinafchi/softwares/FLAME/utils/python/poscar2yaml.py"

    # Paths for the POSCAR and output posinp.yaml
    poscar_path = afopt_poscar_path
    posinp_yaml_path = os.path.join(afopt_dir, 'posinp.yaml')

    # Run the poscar2yaml.py script
    try:
        subprocess.run(['python3', poscar2yaml_script, poscar_path, posinp_yaml_path], check=True)
        print(f"Converted {poscar_path} to {posinp_yaml_path}")
    except subprocess.CalledProcessError as e:
        print(f"Error converting POSCAR to posinp.yaml. Error message: {e}")

def run_commands_in_afopt():
    # 获取当前目录的绝对路径
    current_dir = os.path.abspath('.')
    afopt_dir = os.path.join(current_dir, 'afopt')

    # 确保 afopt 目录存在
    if not os.path.exists(afopt_dir):
        print(f"afopt directory does not exist at {afopt_dir}")
        return

    # 切换到 afopt 目录
    os.chdir(afopt_dir)

    # 运行 flame 程序并将输出重定向到 o1.out
    flame_executable = "/blue/mingjieliu/so.farajinafchi/softwares/FLAME/build-FLAME/src/flame"
    o1_out_path = os.path.join(afopt_dir, 'o1.out')

    try:
        with open(o1_out_path, 'w') as outfile:
            subprocess.run([flame_executable], stdout=outfile, stderr=subprocess.STDOUT, check=True)
        print(f"FLAME execution completed, output saved to {o1_out_path}")
    except subprocess.CalledProcessError as e:
        print(f"Error running FLAME: {e}")
        return

    # 获取当前目录的上级目录名
    parent_dir = os.path.basename(os.path.dirname(afopt_dir))
    print(f"上级目录名为：{parent_dir}")

    # 运行 yaml2poscar.py 脚本，指定输入文件
    yaml2poscar_script = "/blue/mingjieliu/so.farajinafchi/softwares/FLAME/utils/python/yaml2poscar.py"
    posout_yaml_path = os.path.join(afopt_dir, 'posout.yaml')

    if not os.path.exists(posout_yaml_path):
        print(f"posout.yaml does not exist at {posout_yaml_path}")
        return

    try:
        subprocess.run(['python', yaml2poscar_script, posout_yaml_path], check=True)
        print("yaml2poscar.py execution completed.")
    except subprocess.CalledProcessError as e:
        print(f"Error running yaml2poscar.py: {e}")
        return

    # 检查是否生成了 POSCAR 文件
    generated_poscar = os.path.join(afopt_dir, 'POSCAR')
    if os.path.exists(generated_poscar):
        # 重命名 POSCAR 文件为 ${parent_dir}_POSCAR
        renamed_poscar = os.path.join(afopt_dir, f"{parent_dir}_POSCAR")
        os.rename(generated_poscar, renamed_poscar)
        print(f"POSCAR file renamed to {renamed_poscar}")
    else:
        print("Error: POSCAR file not found after running yaml2poscar.py")
        return

    # **去除替换 'Cartesian' 为 'Direct' 的代码**
    print(f"保留 {renamed_poscar} 中的 'Cartesian' 坐标系，不进行替换。")

def main():
    # Step 1: Copy necessary files to 'afopt' directory
    copy_files_to_afopt()

    # Step 2: Extract energy and modify POSCAR
    extract_energy_and_modify_poscar()

    # Step 3: Run required commands in 'afopt' directory
    run_commands_in_afopt()

if __name__ == "__main__":
    main()

