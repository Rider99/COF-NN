#!/bin/bash
#SBATCH --job-name=flame-optwall
#SBATCH --account=mingjieliu
#SBATCH --mail-user=yrui9916@gmail.com
#SBATCH --mail-type=FAIL,END
#SBATCH --nodes=1
#SBATCH --ntasks=32
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G
#SBATCH --time=24:00:00
#SBATCH --output=%x.%j.out
#SBATCH --error=%x.%j.err

set -euo pipefail
cd "$SLURM_SUBMIT_DIR"

module purge
module use /home/mingjieliu/modules
module load gcc/14.2.0 openmpi/5.0.7 flame/1.0
module load python/3.10

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export MKL_NUM_THREADS=$SLURM_CPUS_PER_TASK
export OPENBLAS_NUM_THREADS=$SLURM_CPUS_PER_TASK

srun python3 pre-run_ANN.py

