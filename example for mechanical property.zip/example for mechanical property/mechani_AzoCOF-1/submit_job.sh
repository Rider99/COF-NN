#!/bin/bash
#SBATCH --job-name=post-ann-mech
#SBATCH --account=mingjieliu
#SBATCH --mail-user=yrui9916@gmail.com
#SBATCH --mail-type=FAIL,END
#SBATCH --nodes=1
#SBATCH --ntasks=32
#SBATCH --cpus-per-task=1          # 给 Python/NumPy 的线程
#SBATCH --mem=32G                    # 或者用 --mem-per-cpu=2G 也可
#SBATCH --time=12:00:00
#SBATCH --output=%x.%j.out
#SBATCH --error=%x.%j.err

set -euo pipefail
echo "Job ${SLURM_JOB_ID} starting on $(hostname) at $(date)"
cd "$SLURM_SUBMIT_DIR"

# ---- Modules (HiPerGator) ----
module purge
module use /home/mingjieliu/modules
module load gcc/14.2.0 openmpi/5.0.7 flame/1.0
module load vaspkit/1.4.1            
module load python/3.10        


export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export MKL_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export OPENBLAS_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export NUMEXPR_NUM_THREADS="${SLURM_CPUS_PER_TASK}"

srun -n 1 python -u post-ann-mechani_cal.py

echo "Job ${SLURM_JOB_ID} finished at $(date)"

