#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import shutil
import glob
import subprocess
import argparse
import re
from ase.io import read
from ase.io.vasp import write_vasp

def copy_files_to_current_dir(source_dir, files):
    """
    从 source_dir 复制指定的文件到当前目录。
    """
    print("从源目录复制文件到当前目录...")
    for filename in files:
        src_file = os.path.join(source_dir, filename)
        if os.path.isfile(src_file):
            try:
                shutil.copy(src_file, '.')
                print(f"已复制 {filename}")
            except Exception as e:
                print(f"复制文件 {filename} 时出错: {e}")
        else:
            print(f"源目录中未找到文件 {filename}")

def copy_and_process_poscar():
    """
    从上级目录的 ANN_*_*_c5_opt_COF_TAPB-PDA/afopt 目录复制 POSCAR 文件到当前目录，并使用 ASE 处理。
    """
    print("复制并处理 POSCAR 文件...")
    current_dir = os.getcwd()
    parent_dir = os.path.dirname(current_dir)

    # 匹配上级目录中的 ANN_*_*_c4_opt_COF_151 目录
    pattern = os.path.join(parent_dir, "ANN_*_*_c5_opt_COF_1159")
    matching_dirs = glob.glob(pattern)

    if not matching_dirs:
        print("在上级目录中未找到匹配的 ANN_*_*_c5_opt_COF_1159 目录。")
        exit(1)

    # 假设只有一个匹配的目录
    ann_dir = matching_dirs[0]
    afopt_dir = os.path.join(ann_dir, "afopt")

    # 查找 afopt 子目录中的 POSCAR 文件
    poscar_pattern = os.path.join(afopt_dir, "ANN_*_*_c5_opt_COF_1159_POSCAR")
    poscar_files = glob.glob(poscar_pattern)

    if not poscar_files:
        print("在 afopt 目录中未找到 ANN_*_*_c5_opt_COF_1159_POSCAR 文件。")
        exit(1)

    # 假设只有一个 POSCAR 文件
    poscar_file = poscar_files[0]
    poscar_filename = os.path.basename(poscar_file)
    try:
        shutil.copy(poscar_file, current_dir)
        print(f"已将 {poscar_filename} 复制到当前目录。")

        # 使用 ASE 处理 POSCAR 文件
        structure = read(poscar_filename)
        fractional_positions = structure.get_scaled_positions()
        structure.set_scaled_positions(fractional_positions)
        write_vasp('POSCAR', structure, direct=True)
        print(f"已处理并保存分数坐标的 POSCAR 文件。")
    except Exception as e:
        print(f"处理文件 {poscar_file} 时出错: {e}")

def copy_files_to_current_and_subdirs():
    """
    从当前目录的上三级目录（../../../）复制参数文件，并根据上两级目录名中的数字部分重命名。
    """
    print("复制参数文件...")
    # 获取当前目录的绝对路径
    current_dir = os.path.abspath('.')

    # 获取上两级目录的目录名
    parent_dir_two_up = os.path.basename(os.path.abspath(os.path.join(current_dir, '../../')))

    # 提取目录名中的数字部分
    match = re.search(r'(\d+)', parent_dir_two_up)
    if match:
        number_part = match.group(1)
    else:
        print(f"错误：无法从目录名 {parent_dir_two_up} 中提取数字部分。")
        number_part = 'unknown'

    # 定义源目录（上三级目录）
    source_base_dir = os.path.abspath(os.path.join(current_dir, '../../../'))

    # 要处理的元素列表
    elements = ['C', 'N', 'O', 'H']

    for element in elements:
        source_filename = f"{element}.ann.param.yaml.{number_part}"
        source_file_path = os.path.join(source_base_dir, source_filename)
        target_file_path = os.path.join(current_dir, f"{element}.ann.param.yaml")

        if os.path.exists(source_file_path):
            try:
                shutil.copy(source_file_path, target_file_path)
                print(f"已将 {source_filename} 复制到 {current_dir} 并重命名为 {element}.ann.param.yaml")
            except Exception as e:
                print(f"复制文件 {source_filename} 时出错: {e}")
        else:
            print(f"错误：源文件 {source_file_path} 不存在。")

def copy_files_to_target_dirs():
    """
    将参数文件从当前目录复制到 c11_yaml 和 c12_yaml 目录。
    """
    print("将参数文件复制到 c11_yaml 和 c12_yaml 目录...")
    current_dir = os.getcwd()
    c11_yaml_dir = os.path.join(current_dir, "c11_yaml")
    c12_yaml_dir = os.path.join(current_dir, "c12_yaml")

    # 确保目标目录存在
    os.makedirs(c11_yaml_dir, exist_ok=True)
    os.makedirs(c12_yaml_dir, exist_ok=True)

    # 复制参数文件到 c11_yaml
    for element in ['C', 'N', 'O', 'H']:
        src = os.path.join(current_dir, f"{element}.ann.param.yaml")
        dest = os.path.join(c11_yaml_dir, f"{element}.ann.param.yaml")
        if os.path.exists(src):
            try:
                shutil.copy(src, dest)
                print(f"已复制 {src} 到 {dest}")
            except Exception as e:
                print(f"复制文件 {src} 到 {dest} 时出错: {e}")
        else:
            print(f"参数文件 {src} 不存在，无法复制到 {dest}")

    # 复制参数文件到 c12_yaml
    for element in ['C', 'N', 'O', 'H']:
        src = os.path.join(current_dir, f"{element}.ann.param.yaml")
        dest = os.path.join(c12_yaml_dir, f"{element}.ann.param.yaml")
        if os.path.exists(src):
            try:
                shutil.copy(src, dest)
                print(f"已复制 {src} 到 {dest}")
            except Exception as e:
                print(f"复制文件 {src} 到 {dest} 时出错: {e}")
        else:
            print(f"参数文件 {src} 不存在，无法复制到 {dest}")

def copy_flame_in_yaml(source_flame_in, target_dirs):
    """
    复制 flame_in.yaml 文件到指定的目标目录。
    """
    print("复制 flame_in.yaml 文件...")
    for target_dir in target_dirs:
        try:
            shutil.copy(source_flame_in, target_dir)
            print(f"已复制 flame_in.yaml 到 {target_dir}")
        except Exception as e:
            print(f"复制 flame_in.yaml 到 {target_dir} 时出错：{e}")

def convert_poscar_to_yaml(input_dir, poscar2yaml_path):
    """
    使用 poscar2yaml.py 将指定目录下的 POSCAR 文件转换为 YAML。
    """
    print("转换 POSCAR 文件为 YAML 格式...")
    directories_to_process = ["C11", "C12"]

    for dir_name in directories_to_process:
        input_sub_dir = os.path.join(input_dir, dir_name)
        output_dir = os.path.join(input_dir, f"{dir_name.lower()}_yaml")

        # 确保输出目录存在
        os.makedirs(output_dir, exist_ok=True)

        # 遍历当前目录下的所有子目录
        for sub_dir in os.listdir(input_sub_dir):
            sub_dir_path = os.path.join(input_sub_dir, sub_dir)

            # 确保这是一个目录
            if os.path.isdir(sub_dir_path):
                poscar_file = os.path.join(sub_dir_path, 'POSCAR')

                # 检查 POSCAR 文件是否存在
                if os.path.isfile(poscar_file):
                    output_file_name = f"{dir_name.lower()}+{sub_dir}.yaml"
                    output_path = os.path.join(output_dir, output_file_name)

                    # 使用 subprocess 调用 poscar2yaml.py 脚本
                    command = ["python", poscar2yaml_path, poscar_file, output_path]
                    try:
                        result = subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                        print(f"成功处理 {poscar_file} 并保存为 {output_file_name}")
                    except subprocess.CalledProcessError as e:
                        print(f"处理 {poscar_file} 时出错：{e.stderr.decode()}")
                    except Exception as e:
                        print(f"处理 {poscar_file} 时发生意外错误：{e}")
                else:
                    print(f"文件 {poscar_file} 未找到。")

def run_vaspkit():
    """
    运行 vaspkit 并输入选项 201。
    """
    print("运行 vaspkit 并输入选项 201...")
    try:
        # 使用 subprocess.Popen 以便可以发送输入
        process = subprocess.Popen(['vaspkit'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate(input='201\n')

        if process.returncode == 0:
            print("成功运行 vaspkit 并输入选项 201。")
            print(stdout)
        else:
            print(f"运行 vaspkit 时发生错误：{stderr}")
    except FileNotFoundError:
        print("错误：未找到 'vaspkit' 命令。请确保已安装 vaspkit 并在 PATH 中可用。")
    except Exception as e:
        print(f"运行 vaspkit 时发生异常：{e}")

def concatenate_yaml_files(input_dir, strain_files, output_file):
    """
    将指定的 YAML 文件按顺序合并为一个文件。
    """
    print(f"在 {input_dir} 中合并 YAML 文件到 {output_file}...")
    with open(output_file, 'w') as outfile:
        for filename in strain_files:
            file_path = os.path.join(input_dir, filename)
            if os.path.isfile(file_path):
                try:
                    with open(file_path, 'r') as infile:
                        outfile.write(infile.read())
                        outfile.write("\n")  # 添加换行符
                    print(f"已合并 {filename}")
                except Exception as e:
                    print(f"读取文件 {filename} 时出错：{e}")
            else:
                print(f"文件 {filename} 未找到。")
    print(f"所有文件已合并到 {output_file}")
def main():
    # 定义命令行参数解析器
    parser = argparse.ArgumentParser(description="预处理 ANN 机械计算的脚本。")
    parser.add_argument('--source_dir', type=str, default="/blue/mingjieliu/yunrui.yan/Train/train_Behler_c3/train0055/test00017/test_COF/ANN_mechani", help="源目录路径")
    parser.add_argument('--poscar2yaml_path', type=str, default="/blue/mingjieliu/so.farajinafchi/softwares/FLAME/utils/python/poscar2yaml.py", help="poscar2yaml.py 脚本的路径")
    parser.add_argument('--flame_in_source', type=str, default="/blue/mingjieliu/yunrui.yan/Train/train_Behler_c5/train0107/test00012/SP_traindp/flame_in.yaml", help="flame_in.yaml 的源路径（绝对路径>）")
    args = parser.parse_args()

    # 当前目录
    current_dir = os.getcwd()

    # 步骤 1：复制文件到当前目录
    files_to_copy = ["POTCAR", "INCAR", "KPOINTS", "OUTCAR"]
    copy_files_to_current_dir(args.source_dir, files_to_copy)

    # 步骤 2：复制并处理 POSCAR 文件
    copy_and_process_poscar()

    # 步骤 3：复制并重命名参数文件
    copy_files_to_current_and_subdirs()

    # 步骤 4：将参数文件复制到 c11_yaml 和 c12_yaml 目录
    copy_files_to_target_dirs()

    # 步骤 5：复制 flame_in.yaml 文件
    # 使用用户提供的 flame_in.yaml 的绝对路径
    c11_yaml_dir = os.path.join(current_dir, "c11_yaml")
    c12_yaml_dir = os.path.join(current_dir, "c12_yaml")
    copy_flame_in_yaml(args.flame_in_source, [c11_yaml_dir, c12_yaml_dir])

    # 步骤 6：运行 VASPkit
    run_vaspkit()

    # 步骤 7：转换 POSCAR 文件为 YAML
    convert_poscar_to_yaml(current_dir, args.poscar2yaml_path)

    # 步骤 8：合并 YAML 文件
    # 定义 C11 的 strain 文件顺序
    c11_strain_files = [
        "c11+strain_-0.030.yaml",
        "c11+strain_-0.020.yaml",
        "c11+strain_-0.010.yaml",
        "c11+strain_0.000.yaml",
        "c11+strain_+0.010.yaml",
        "c11+strain_+0.020.yaml",
        "c11+strain_+0.030.yaml"
    ]

    # 定义 C12 的 strain 文件顺序
    c12_strain_files = [
        "c12+strain_-0.030.yaml",
        "c12+strain_-0.020.yaml",
        "c12+strain_-0.010.yaml",
        "c12+strain_0.000.yaml",
        "c12+strain_+0.010.yaml",
        "c12+strain_+0.020.yaml",
        "c12+strain_+0.030.yaml"
    ]

    # 合并 C11 的 YAML 文件
    c11_output_file = os.path.join(c11_yaml_dir, 'posinp.yaml')
    concatenate_yaml_files(c11_yaml_dir, c11_strain_files, c11_output_file)

    # 合并 C12 的 YAML 文件
    c12_output_file = os.path.join(c12_yaml_dir, 'posinp.yaml')
    concatenate_yaml_files(c12_yaml_dir, c12_strain_files, c12_output_file)

    print("所有步骤已完成。")

if __name__ == "__main__":
    main()

