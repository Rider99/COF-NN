
#!/bin/bash
#SBATCH --job-name=VASP
#SBATCH --mail-user=yunrui.yan@ufl.edu
#SBATCH --mail-type=FAIL
#SBATCH --output=vasp.out
#SBATCH --error=vasp.err
#SBATCH --nodes=1
#SBATCH --ntasks=32
#SBATCH --cpus-per-task=1
#SBATCH --ntasks-per-socket=8
#SBATCH --mem-per-cpu=4gb
#SBATCH --time=13:00:00
#SBATCH --distribution=cyclic:cyclic
#SBATCH --account=mingjieliu
#SBATCH --qos=mingjieliu-b
#SBATCH --constraint=el8

module purge
module load nvhpc/23.7 openmpi/4.1.5 vasp/6.4.1


srun  vasp_std

