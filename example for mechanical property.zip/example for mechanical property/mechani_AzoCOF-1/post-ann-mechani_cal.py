#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import subprocess
import shutil
import yaml

# 第一步：在 c11_yaml 和 c12_yaml 目录中运行 FLAME
def run_flame():
    current_dir = os.getcwd()
    directories_to_process = ["c11_yaml", "c12_yaml"]

    for dir_name in directories_to_process:
        target_dir = os.path.join(current_dir, dir_name)
        if os.path.isdir(target_dir):
            print(f"在 {target_dir} 运行 FLAME...")
            try:
                # 使用 subprocess 运行 FLAME
                result = subprocess.run(
                    ["/blue/mingjieliu/so.farajinafchi/softwares/FLAME/build-FLAME/src/flame"],
                    cwd=target_dir,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    shell=True  # 设置 shell=True 以便于重定向输出
                )

                # 将输出保存到 o1.out 文件
                with open(os.path.join(target_dir, "o1.out"), 'w') as output_file:
                    output_file.write(result.stdout.decode())

                print(f"FLAME 已在 {target_dir} 运行完成。")

            except subprocess.CalledProcessError as e:
                print(f"在 {target_dir} 运行 FLAME 时出错：{e.stderr.decode()}")
            except Exception as e:
                print(f"在 {target_dir} 运行 FLAME 时发生意外错误：{e}")
        else:
            print(f"目录 {target_dir} 不存在，无法运行 FLAME。")

# 第二步：将当前目录下的 OUTCAR 文件复制到当前目录的 C11 和 C12 的所有子目录
def copy_outcar_to_subdirs():
    current_dir = os.getcwd()
    base_dirs = [
        os.path.join(current_dir, "C11"),
        os.path.join(current_dir, "C12")
    ]

    for base_dir in base_dirs:
        if not os.path.isdir(base_dir):
            print(f"目录 {base_dir} 不存在，跳过复制。")
            continue

        for sub_dir in os.listdir(base_dir):
            sub_dir_path = os.path.join(base_dir, sub_dir)
            if os.path.isdir(sub_dir_path):
                outcar_source = os.path.join(current_dir, 'OUTCAR')
                outcar_target = os.path.join(sub_dir_path, 'OUTCAR')
                if os.path.isfile(outcar_source):
                    try:
                        shutil.copy(outcar_source, outcar_target)
                        print(f"已将 OUTCAR 文件复制到 {sub_dir_path}")
                    except Exception as e:
                        print(f"复制 OUTCAR 文件到 {sub_dir_path} 时出错：{e}")
                else:
                    print(f"未找到模板 OUTCAR 文件 {outcar_source}，无法复制。")

# 第三步：从 posout.yaml 生成 OUTCAR 文件
def generate_outcar_files():
    # 定义 Hartree 到 eV 的转换因子
    hartree_to_ev = 27.2114

    # 定义路径和输出映射
    data = [
        {
            "yaml_file_path": os.path.join(os.getcwd(), "c11_yaml", "posout.yaml"),
            "base_dir": os.path.join(os.getcwd(), "C11")
        },
        {
            "yaml_file_path": os.path.join(os.getcwd(), "c12_yaml", "posout.yaml"),
            "base_dir": os.path.join(os.getcwd(), "C12")
        }
    ]

    # 定义输出文件名和子目录的对应关系
    output_mappings = {
        '-0.030_OUTCAR': 'strain_-0.030',
        '-0.020_OUTCAR': 'strain_-0.020',
        '-0.010_OUTCAR': 'strain_-0.010',
        '0.000_OUTCAR': 'strain_0.000',
        '0.010_OUTCAR': 'strain_+0.010',
        '0.020_OUTCAR': 'strain_+0.020',
        '0.030_OUTCAR': 'strain_+0.030'
    }

    # 读取原始 OUTCAR 文件内容
    outcar_template_path = 'OUTCAR'
    if not os.path.isfile(outcar_template_path):
        print(f"未找到模板文件 {outcar_template_path}")
        return

    with open(outcar_template_path, 'r') as file:
        outcar_template = file.read()

    # 遍历每组数据
    for entry in data:
        yaml_file_path = entry["yaml_file_path"]
        base_dir = entry["base_dir"]

        # 加载 YAML 文件
        try:
            with open(yaml_file_path, 'r') as file:
                yaml_documents = list(yaml.load_all(file, Loader=yaml.FullLoader))
        except FileNotFoundError:
            print(f"未找到 YAML 文件 {yaml_file_path}")
            continue
        except Exception as e:
            print(f"加载 YAML 文件 {yaml_file_path} 时发生错误：{e}")
            continue

        # 提取并转换能量值
        energy_values_ev = [
            doc['conf']['epot'] * hartree_to_ev
            for doc in yaml_documents if 'conf' in doc and 'epot' in doc['conf']
        ]

        # 创建 OUTCAR 文件并保存到相应子目录
        for i, energy in enumerate(energy_values_ev):
            if i >= len(output_mappings):
                print("警告：能量值的数量超过了输出映射的数量，跳过多余的能量值。")
                break

            # 获取输出文件名和对应的子目录
            outcar_file_name = list(output_mappings.keys())[i]
            subdirectory = output_mappings[outcar_file_name]
            outcar_file_path = os.path.join(base_dir, subdirectory, 'OUTCAR')

            # 在模板中替换能量值
            content_outcar = outcar_template.replace('-84360.3225231950', f"{energy:20.10f}")

            # 确保目标子目录存在
            os.makedirs(os.path.dirname(outcar_file_path), exist_ok=True)

            # 保存 OUTCAR 文件
            try:
                with open(outcar_file_path, 'w') as outcar_file:
                    outcar_file.write(content_outcar)
                print(f"生成文件：{outcar_file_path}")
            except Exception as e:
                print(f"保存文件 {outcar_file_path} 时发生错误：{e}")

    print("所有文件生成完成。")

# 第四步：运行 VASPkit 并输入选项 201
def run_vaspkit():
    print("运行 VASPkit 并输入选项 201...")
    try:
        # 使用 subprocess.Popen 以便可以发送输入
        process = subprocess.Popen(['vaspkit'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate(input='201\n')

        if process.returncode == 0:
            print("成功运行 VASPkit 并输入选项 201。")
            print(stdout)
        else:
            print(f"运行 VASPkit 时发生错误：{stderr}")
    except FileNotFoundError:
        print("错误：未找到 'vaspkit' 命令。请确保已安装 VASPkit 并在 PATH 中可用。")
    except Exception as e:
        print(f"运行 VASPkit 时发生异常：{e}")

# 主函数
def main():
    # 第一步：在 c11_yaml 和 c12_yaml 目录中运行 FLAME
    run_flame()

    # 第二步：将当前目录下的 OUTCAR 文件复制到 C11 和 C12 的所有子目录中
    copy_outcar_to_subdirs()

    # 第三步：从 posout.yaml 生成 OUTCAR 文件
    generate_outcar_files()

    # 第四步：运行 VASPkit
    run_vaspkit()

if __name__ == "__main__":
    main()

